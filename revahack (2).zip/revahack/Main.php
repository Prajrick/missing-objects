<style>
    .GFG{
        background-color: rgba(247, 142, 6, 0.966);
        border: 2px solid rgba(233, 118, 10, 0.856);
        color: rgb(11, 12, 11);
        padding: 5px 10px;
        text-align: center;
        display: inline-block;
        font-size: 20px;
        margin: 10px 30px;
        cursor: pointer;
    }
    .button{
        position: absolute;
        top: 60%;
        left: 50%;
        transform: translate(-50%,-50%);
        border-radius: 10px;

    }
    .button2{
        position: absolute;
        font-size: 25pt;
        width: 180px;
        top: -275px;
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        background-color: rgba(0, 0, 0, 0.377);
        border: 1px solid white;
        border-radius: 5px;
        color:white;
        left: 635px;
        height: 50px;
        transform: translate(-50%,-50%);
    }
    .btn{
        border: 1px solid #fff;
        padding: 10px 30px;
        color: #fff;
        text-decoration: none;
    }
    body{
        background-image: url('Main Page.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 100%;
        background-color: rgb(17, 51, 51);
    }
    header{
        background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5));
        height: 100vh;
        background-size:cover ;
        background-position: center;
    }
    ul{
        float: right;
        list-style-type: none;
        margin-top: 25px;

    }
    ul li{
        display: inline-block;
    }
    ul li a{
        text-decoration: none;
        color: #fff;
        padding: 5px 20px;
        border: 1px solid transparent;
        transition: 0.6s ease;
    }
    ul li a:hover{
        background-color: #fff;
        color: #000;
    }
    ul li.active a{
        background-color: #fff;
        color: #000;
    }
    .logo img{
        float:left;
        width: 350px;
        height:auto;
        padding-top: 20px;
    }
    .main{
        max-width: 1450px;
        margin: auto;
    }
    .title{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
    }
    .title h1{
        color: #fff;
        font-size: 50px;
    }


</style>
<html>
<head>
    <title>MAIN PAGE</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
    <body >
        <header>
            <div class="main">
                <div class="logo">
                    <img src="REVA logo-169_40px.png">
                </div>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="Start_page.html">Log Out</a></li>
                </ul>
            </div>
            <div class="title">
                <button class="button2">Found</button>
            </div>
            <div class="button">
                <a href="https://ide.geeksforgeeks.org/" class="btn">Back</a>
                <a href="https://ide.geeksforgeeks.org/" class="btn">Next</a>
            </div>
        </header>
        <!--<a href='https://ide.geeksforgeeks.org/'>
            <button style="";";" class="GFG" >
                FOUND
            </button>
        </a>
        <a href="https://googl.com/">
            <button style="margin:center;" class="GFG">
                CLAIM
            </button>
        </a>-->
    </body>
</html>