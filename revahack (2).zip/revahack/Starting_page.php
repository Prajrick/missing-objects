<style>
    body {
    opacity: 2;
    background-image: url("Reva Outside.jpg");
    background-repeat:  no-repeat;
    background-attachment: fixed;
    background-size: 100% 100%;
  }
  

.my-button{
    width: 200px;
    height: 100px;
    position: absolute;
    top: 175px;
    right: 400px;
    font-size: 22px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    background-color: rgba(0, 0, 0, 0.548);
    color:rgb(255, 255, 255);
    border: 1px solid white;
    border-radius: 5px;
    
}

.my-button2{
    width: 200px;
    height: 100px;
    position: absolute;
    top: 175px;
    right: 725px;
    font-size: 22px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    background-color: rgba(0, 0, 0, 0.548);
    color:white;
    border: 1px solid white;
    border-radius: 5px;
}

.headerlogo {
    position: absolute;
    left:0px;
    top: 0px;
}


  body {
 padding-top: 25px;
}



</style>














	 
 <html>
     <head></head>
         <body>
            <marquee style= "font-size: 20pt; color: rgb(255, 255, 255); font-family: Verdana, Geneva, Tahoma, sans-serif;" width="21%" direction="left" height="300px" hspace="600">
               Lost Elsewhere? Found Here!
                </marquee>
        </div> 
        <br>
        <div class="headerlogo" ,position: absolute;><img src="Reva White Logo.png" width="300" height="100" ></div>

            
            <div style="background-image: url('Reva\ Outside.jpg');"></div>
        
            <div style = "position:absolute; left:175px; top:200px; background-color:rgba(0, 0, 0, 0.548);border-radius: 10px; width:1250; height:300px;">
                <p style="font-size:14pt;color:white;font-family: Verdana, Geneva, Tahoma, sans-serif; text-align: center; "> &nbsp; Welcome! <br><br> &nbsp;This is a student built digital platform to facilitate college people to find their lost property. <br> &nbsp; Any found materials in campus can be putup on the page. The student can have an easy login access through their SRN and use the portal efficiently. The owner can claim their belongings through the description given and collect it from the drop location.</p>

           <form action="signup.php" method="post">
            <button class="my-button" name="signup">Sign Up</button>

            <button class="my-button2"><a href="Login.php" style="color: rgb(255, 255, 255)">Log In</a></button>
            </form>

            
    </div>
            
         </body>
 </html>