<style>
    body {
    background-image: url("REVA BGP.jpg");
    background-color: #FF000000;
    background-repeat:  no-repeat;
    background-attachment: fixed;
    background-size: 100% 100%;
  }
   form{text-align: center;
} 

   .logo{
       display: inline-block;
       position:absolute;
       top: 20pt;

   }

.my-button{
    width: 200px;
    height: 30px;
    font-size: 15px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    background-color: rgb(33, 62, 223);
    color:white;
    border: 1px solid white;
    border-radius: 5px;
}

</style>













<div id="logo"> 
	 
 <html>
     <head></head>
         <body>
        </div> 
        <br>
        <h1>
        <div class="logo" ,postion: absolute;><img src="REVA logo-169_40px.png" width="300" height="100" ></div>
        <form name="regForm">
            
            <div style="background-image: url('REVA\ BGP.jpg');"></div>
            <div style = "position:absolute; left:550px; top:300px; background-color:rgba(0, 0, 0, 0.548);border-radius: 10px; width:450px; height:325px;">
            <p style="font-size:12pt;color:white;font-family: Verdana, Geneva, Tahoma, sans-serif; ">Welcome, Please follow the below instructions to finding your missing item.</p>
            <label><input style=height:30px;border-radius:7px;font-size:14pt type="text" placeholder="Enter Your Name"></label> <br>
            <br>
            <label><input style=height:30px;border-radius:7px;font-size:14pt type="text" placeholder="Enter SRN No." ></label>
            <br>
            <br><label><input style=height:30px;border-radius:7px;font-size:14pt type="password" placeholder="Set a password"></label>
            <br>
            <br>
            <button class="my-button">Sign Up</button>
        </h1>
            </form>
         </body>
 </html>